
The simplest way to formulate the report is by editting the predefined template file in LaTeX rather than 
going to design the template by yourself

1) Save the downloaded file as X:\Thesis template
2) Run the  X:\Thesis template\Theis_templte.tex file to view the basic layout of the template
3) Do the necessary edits in  X:\Thesis template\x.tex files as per instructions provided in  X:\Thesis template\template_guide.pdf 
4) Do save the images in the X:\Thesis template\img foler for better results